$(document).ready(function() {
    // Initialize Swiper
    let mySwiper = new Swiper('.swiper-container', {
        direction: 'horizontal', 
        loop: true, 
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        }
    });
});
