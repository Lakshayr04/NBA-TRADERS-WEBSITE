const express = require('express');
const bodyParser = require('body-parser');
const sendEmail = require('https://mail.google.com/mail/u/0/#inbox'); // Replace with the actual path
const cors = require('cors'); // Import cors

const app = express();
const port = 3000;

app.use(cors()); // Enable CORS
app.use(bodyParser.json());


// Define an endpoint for sending emails
app.post('sendEmail', (req, res) => {
    const formData = req.body;

    // Call the sendEmail function
    sendEmail(formData);

    // Respond to the client
    res.status(200).send('Email sent successfully');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
