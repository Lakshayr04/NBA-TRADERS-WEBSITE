<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];

    
    echo "<span><span><br>" ; 
    echo "<span><span><br>";
    echo "<span>lakshayr04@gmail.com<span>"<br>
    

    // echo $firstname;
    // echo $lastname;
    echo $email;
}
?>
