function submitForm() {
    var selectedItems = [];

    $("input[name='itemCheckbox']:checked").each(function () {
        var row = $(this).closest('tr');
        var brand = row.find('td:eq(1)').text();
        var type = row.find('td:eq(2)').text();
        var material = row.find('td:eq(3)').text();
        var price = row.find('td:eq(4)').text();
        var image = row.find('img').attr("src");

        selectedItems.push({
            brand: brand,
            type: type,
            material: material,
            price: price,
            image: image
        });
    });

    // Convert the selectedItems array to a JSON string
    var selectedItemsJSON = JSON.stringify(selectedItems);

    // Use encodeURIComponent to safely include the JSON string in the URL
    window.location.href = "result.html?selectedItems=" + encodeURIComponent(selectedItemsJSON);
}
